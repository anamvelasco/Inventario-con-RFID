#include "mfrc522.h"
#include "pico_keypad4x4.h"
#include "lcd_1602_i2c.h"
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include "pico/stdlib.h"
#include "hardware/flash.h"
#include "hardware/spi.h"
#include "hardware/sync.h"
#include "hardware/gpio.h"
#include "hardware/timer.h"

uint get_password();
void admin_card_authentication();
void gpio_callback(uint gpio, uint32_t events);
void send_to_lcd(char *message[], int num_messages);
bool is_fully_set(char *pin);
void readMaxProductsFromSector2Block2();
void readProductInfoFromSector4Block2();
const char* getProductName(int productCode);
void loop();

uint columns[4] = { 10, 11, 12, 13 };
uint rows[4] = { 6, 7, 8, 9 };
char matrix[16] = {
    '1', '2', '3', 'A',
    '4', '5', '6', 'B',
    '7', '8', '9', 'C',
    '*', '0', '#', 'D'
};

volatile char last_key = '\0';
volatile bool key_pressed = false;
uint password = 0;
char security_pin[5] = "****";  // 4 characters + null terminator
bool logged = false;
bool capacity_card_undetected = true;
MFRC522Ptr_t mfrc522_3;

// Max amount of boxes that can be saved inside the warehouse (per type of product)
int max_prod_1 = 5;
int max_prod_2 = 1;
int max_prod_3 = 3;
int max_prod_4 = 2;
int max_prod_5 = 4;

int main() {
    stdio_init_all();
    pico_keypad_init(columns, rows, matrix);
    spi_init(spi0, 1000 * 1000);

    #if !defined(i2c_default) || !defined(PICO_DEFAULT_I2C_SDA_PIN) || !defined(PICO_DEFAULT_I2C_SCL_PIN)
    #warning i2c/lcd_1602_i2c example requires a board with I2C pins
    #else
    // This example will use I2C0 on the default SDA and SCL pins (4, 5 on a Pico)
    i2c_init(i2c_default, 100 * 1000);
    gpio_set_function(PICO_DEFAULT_I2C_SDA_PIN, GPIO_FUNC_I2C);
    gpio_set_function(PICO_DEFAULT_I2C_SCL_PIN, GPIO_FUNC_I2C);
    gpio_pull_up(PICO_DEFAULT_I2C_SDA_PIN);
    gpio_pull_up(PICO_DEFAULT_I2C_SCL_PIN);
    // Make the I2C pins available to picotool
    bi_decl(bi_2pins_with_func(PICO_DEFAULT_I2C_SDA_PIN, PICO_DEFAULT_I2C_SCL_PIN, GPIO_FUNC_I2C));

    lcd_init();

    static char *message[] = {
        "Bienvenido al", "sistema",
        "de inventario", " :) ",
    };

    static char *message2[] = {
        "Ingrese PIN", "de seguridad:",
    };

    static char *message3[] = {
        "Admin autorizado", "con exito!",
    };

    static char *message4[] = {
        "Por favor, ", "Indique: ",
        "Capacidad", "de la bodega",
    };

    sleep_ms(500);
    while (!logged) {
        printf("\nBienvenido al sistema de inventario");
        send_to_lcd(message, sizeof(message) / sizeof(message[0]));
        admin_card_authentication();
        //sleep_ms(3000);

        printf("\nIngrese PIN de seguridad: ");
        send_to_lcd(message2, sizeof(message2) / sizeof(message2[0]));
        //sleep_ms(3000);

        password = get_password();
        printf("\nPIN ingresado: %u", password);

        // Setup GPIO interrupts for the keypad columns
        pico_keypad_irq_enable(true, gpio_callback);

        int index = 0;

        while (!is_fully_set(security_pin)) {
            if (key_pressed) {
                security_pin[index] = last_key;
                index++;
                key_pressed = false;
            }
        }

        if (security_pin[0] == '2' && security_pin[1] == '0' && security_pin[2] == '0' && security_pin[3] == '1') {
            printf("\nPIN correcto!.");
            logged = true;

        } else {
            printf("\nINTENTALO DE NUEVO");
            logged = false;
        }
    }

    send_to_lcd(message3, sizeof(message3) / sizeof(message3[0]));
    //sleep_ms(3000);
    printf("\n\nAdministrador autenticado con éxito\n");
    printf("\n");

    // Setup GPIO interrupts for the keypad columns
    pico_keypad_irq_enable(false, gpio_callback);

    // Aqui viene la etapa de deteccion de cajas
    send_to_lcd(message4, sizeof(message4) / sizeof(message4[0])); // "Por favor, indique la capacidad de la bodega"
    readMaxProductsFromSector2Block2();

    send_to_lcd(message3, sizeof(message3) / sizeof(message3[0]));
    printf("\n\nCapacidad de bodega:\n");
    printf("tipo 1: %u\n", max_prod_1);
    printf("tipo 2: %u\n", max_prod_2);
    printf("tipo 3: %u\n", max_prod_3);
    printf("tipo 4: %u\n", max_prod_4);
    printf("tipo 5: %u\n", max_prod_5);
    printf("\n");
    printf("AHORA VIENE LA DETECCION DE CAJAS");
    
    mfrc522_3 = MFRC522_Init();
    PCD_Init(mfrc522_3, spi0);
    readProductInfoFromSector4Block2();
    printf("\nFINALIZADA LA DETECCION DE CAJAS\n");
    while(1){
    }

    #endif
    return 0;
}

void admin_card_authentication() {
    // Declare card UID's
    uint8_t tag1[] = {0xBA, 0x78, 0x82, 0x77};
    // Declare authentication variables
    bool authorized_card = false; // True if the RFID authentication card matches its UID. False in other case.
    uint password = 2001; // Admin password. If the introduces value matches this password AND authorized card is TRUE, Autherized returns TRUE.

    MFRC522Ptr_t mfrc = MFRC522_Init();
    PCD_Init(mfrc, spi0);

    sleep_ms(500);
    while (!authorized_card) {
        // Wait for new card
        printf("\nWaiting for card\n\r");
        while (!PICC_IsNewCardPresent(mfrc));
        // Select the card
        printf("Selecting card\n\r");
        PICC_ReadCardSerial(mfrc);

        // Show UID on serial monitor
        printf("PICC dump: \n\r");
        PICC_DumpToSerial(mfrc, &(mfrc->uid));

        // Authorization with uid
        printf("Uid is: ");
        for (int i = 0; i < 4; i++) {
            printf("%x ", mfrc->uid.uidByte[i]);
        }
        printf("\n\r");

        if (memcmp(mfrc->uid.uidByte, tag1, 4) == 0) {
            printf("Authentication Success\n\r");
            authorized_card = true;
        } else {
            printf("Authentication Failed\n\r");
            authorized_card = false;
        }
    }
}

uint get_password() {
    uint password = 2001; // Instead of this, get password by keypad handling.
    return password;
}

void gpio_callback(uint gpio, uint32_t events) {
    if (!debounce_time_passed()) {
        return;
    }

    char key = pico_keypad_get_key();
    if (key != '\0') {
        printf("Key pressed: %c\n", key);
        last_key = key;
        key_pressed = true;
        last_press_time = get_absolute_time();
    }
}

void send_to_lcd(char *message[], int num_messages) {
    for (int m = 0; m < num_messages; m += MAX_LINES) {
        for (int line = 0; line < MAX_LINES; line++) {
            lcd_set_cursor(line, (MAX_CHARS / 2) - strlen(message[m + line]) / 2);
            lcd_string(message[m + line]);
        }
        sleep_ms(2000);
        lcd_clear();
    }
}

bool is_fully_set(char *pin) {
    for (int i = 0; i < 4; i++) {
        if (pin[i] == '*') {
            return false;
        }
    }
    return true;
}

void readMaxProductsFromSector2Block2() {
    printf("\nGOT INSIDE THE FUNCTION\n");

    // Initialize the RFID reader
    MFRC522Ptr_t mfrc522 = MFRC522_Init();
    PCD_Init(mfrc522, spi0);

    // Define the UID of the valid card
    uint8_t validUID[] = {0x85, 0x28, 0xEE, 0xC7};
    MIFARE_Key key;
    for (uint8_t i = 0; i < 6; i++) key.keybyte[i] = 0xFF;  // Default key

    bool validCardDetected = false;

    while (!validCardDetected) {
        // Wait for a new card to be present
        printf("Waiting for card\n");
        while (!PICC_IsNewCardPresent(mfrc522));

        // Select the card
        printf("Card detected, selecting card\n");
        if (PICC_ReadCardSerial(mfrc522)) {
            printf("Card selected\n");

            // Check if the card's UID matches the valid UID
            if (memcmp(mfrc522->uid.uidByte, validUID, 4) == 0) {
                printf("Valid card detected\n");

                // Authenticate sector 2, block 2
                printf("\nPASSED THE 1ST FOR LOOP\n");
                if (PCD_Authenticate(mfrc522, PICC_CMD_MF_AUTH_KEY_A, 2 * 4 + 2, &key, &(mfrc522->uid)) == STATUS_OK) {
                    uint8_t buffer[18];
                    uint8_t bufferSize = sizeof(buffer);

                    printf("\nGOT INSIDE 1ST IF\n");

                    // Read data from sector 2, block 2
                    if (MIFARE_Read(mfrc522, 2 * 4 + 2, buffer, &bufferSize) == STATUS_OK) {
                        printf("\nGOT INSIDE 2ND IF\n");
                        printf("32 Nibbles: ");
                        for (int i = 0; i < 16; i++) {
                            printf("%02X ", buffer[i]);
                        }
                        printf("\n");

                        // Extract the 12-bit quantities for each product type from the buffer
                        int maxProducts[5];
                        maxProducts[0] = ((buffer[8] << 8) | buffer[9]) & 0xFFF;  // Type 1
                        maxProducts[1] = ((buffer[10] << 4) | (buffer[11] >> 4)) & 0xFFF; // Type 2
                        maxProducts[2] = ((buffer[11] << 8) | buffer[12]) & 0xFFF; // Type 3
                        maxProducts[3] = ((buffer[13] << 4) | (buffer[14] >> 4)) & 0xFFF; // Type 4
                        maxProducts[4] = ((buffer[14] << 8) | buffer[15]) & 0xFFF; // Type 5

                        printf("Max Products:\n");
                        for (int i = 0; i < 5; i++) {
                            printf("Type %d: %d\n", i + 1, maxProducts[i]);
                        }

                        // Update global max_prod variables
                        max_prod_1 = maxProducts[0];
                        max_prod_2 = maxProducts[1];
                        max_prod_3 = maxProducts[2];
                        max_prod_4 = maxProducts[3];
                        max_prod_5 = maxProducts[4];

                        validCardDetected = true;  // Successfully read the valid card and extracted the data
                    } else {
                        printf("Error reading the block.\n");
                    }
                } else {
                    printf("Error authenticating the block.\n");
                }

                PICC_HaltA(mfrc522);  // Halt the PICC
            } else {
                printf("Invalid card detected\n");
            }
        } else {
            printf("Failed to select card\n");
        }
    }

    printf("\nFINISHED\n");
    //sleep_ms(2000);
    // Add return statement to exit the function
    return;
}

void readProductInfoFromSector4Block2() {
    // Initialize the RFID reader
    MFRC522Ptr_t mfrc522 = MFRC522_Init();
    PCD_Init(mfrc522, spi0);

    // Buffer to store the data read from the block
    uint8_t buffer[18];
    uint8_t bufferSize = sizeof(buffer);

    // Attempt to read data from sector 4, block 2
    if (MIFARE_Read(mfrc522, 4 * 4 + 2, buffer, &bufferSize) == STATUS_OK) {
        // Extract the product information from the buffer
        uint8_t productType = buffer[15] & 0x0F;
        uint16_t quantity = (((buffer[14]) << 8) | (buffer[15] & 0xF0)) >> 4;
        uint16_t price = (buffer[12] << 8) | (buffer[13]);
        uint16_t sellingPrice = (buffer[10] << 8) | (buffer[11]);

        // Convert the product type to a product name
        const char* productName = getProductName(productType);

        // Print or store the extracted product information
        printf("Product Information:\n");
        printf("Tipo de Producto: %s\n", productName);
        printf("Cantidad de Producto: %d\n", quantity);
        printf("Precio Unitario: %d\n", price);
        printf("Precio de Venta: %d\n", sellingPrice);
    } else {
        printf("Error reading the block.\n");
    }

    // Halt the card to allow reading of new cards
    PICC_HaltA(mfrc522);
}




const char* getProductName(int productCode) {
    switch (productCode) {
        case 1:
            return "Producto 1";
        case 2:
            return "Producto 2";
        case 3:
            return "Producto 3";
        case 4:
            return "Producto 4";
        case 5:
            return "Producto 5";
        default:
            return "Producto Desconocido";
    }
}