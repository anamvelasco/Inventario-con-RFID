var searchData=
[
  ['mf_5fack_0',['MF_ACK',['../mfrc522_8h.html#a53ebd42d413bbb43ea0113768e19b4eda6dd7352ca68c1417e09901968b4c5719',1,'mfrc522.h']]],
  ['mf_5fkey_5fsize_1',['MF_KEY_SIZE',['../mfrc522_8h.html#a53ebd42d413bbb43ea0113768e19b4eda89cd0583cf0d34f501a9d54d3c9f1567',1,'mfrc522.h']]],
  ['mfrxreg_2',['MfRxReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aa6d10e82f72bcb35d058b089f5c38544a',1,'mfrc522.h']]],
  ['mftxreg_3',['MfTxReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aa93d56e6001bd85c41e2158d21b16f2d5',1,'mfrc522.h']]],
  ['modereg_4',['ModeReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aa7415e07bcec5d07b9ffb82f77267e664',1,'mfrc522.h']]],
  ['modgspreg_5',['ModGsPReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aae9701fa041e47870dfa008dda7f3c403',1,'mfrc522.h']]],
  ['modwidthreg_6',['ModWidthReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aaa70266e775878057377465fe90ea3d61',1,'mfrc522.h']]]
];
