var searchData=
[
  ['version_2eh_0',['version.h',['../version_8h.html',1,'']]],
  ['versionreg_1',['VersionReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aa1bd073562b1eb057ff4658b80d81b016',1,'mfrc522.h']]]
];
