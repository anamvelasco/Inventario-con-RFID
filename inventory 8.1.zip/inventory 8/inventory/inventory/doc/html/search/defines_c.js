var searchData=
[
  ['type_5foffset_0',['TYPE_OFFSET',['../inventory_8h.html#a0d959bab8012ca35fae09feb874628d7',1,'inventory.h']]]
];
