var searchData=
[
  ['pcd_5fcommand_0',['PCD_Command',['../mfrc522_8h.html#a617683bfa818f4980ae8caeb0860b78d',1,'mfrc522.h']]],
  ['pcd_5frxgain_1',['PCD_RxGain',['../mfrc522_8h.html#ab7f9cfd7a0569eef260ca9b823a212e8',1,'mfrc522.h']]],
  ['picc_5fcommand_2',['PICC_Command',['../mfrc522_8h.html#a611c0fc00ca6cd7685dbb6116b74ca88',1,'mfrc522.h']]],
  ['picc_5ftype_3',['PICC_Type',['../mfrc522_8h.html#a44a705567f16f88fb19ed57faf327140',1,'mfrc522.h']]]
];
