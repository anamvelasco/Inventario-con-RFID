var searchData=
[
  ['bitframingreg_0',['BitFramingReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aa151ffe13df9f13c2af35ba5266501892',1,'mfrc522.h']]],
  ['buffer_5fsize_1',['BUFFER_SIZE',['../mfrc522_8h.html#a6b20d41d6252e9871430c242cb1a56e7',1,'mfrc522.h']]],
  ['button_5fhandler_2',['button_handler',['../inventory_8h.html#a0ac796e83f1cf69816f9e8cb8262453f',1,'inventory.h']]],
  ['button_5fpin_3',['BUTTON_PIN',['../inventory_8h.html#abc2ad14f0789907024ac765711ffd3da',1,'inventory.h']]]
];
