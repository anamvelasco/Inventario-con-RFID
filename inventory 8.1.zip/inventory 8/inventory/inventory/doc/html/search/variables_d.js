var searchData=
[
  ['uid_0',['uid',['../struct_m_f_r_c522___t.html#ad21d7964ad3cdee8b176103c96068ce3',1,'MFRC522_T']]],
  ['uidbyte_1',['uidByte',['../struct_uid.html#aafb8e9739bf46524e7aae2e6242c341e',1,'Uid']]]
];
