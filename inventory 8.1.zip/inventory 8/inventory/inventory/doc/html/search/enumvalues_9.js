var searchData=
[
  ['rfcfgreg_0',['RFCfgReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aae1aa405761bba36ad03d111aa1b4b050',1,'mfrc522.h']]],
  ['rxgain_5f18db_1',['RxGain_18dB',['../mfrc522_8h.html#a05e738f69d5036abf5520bd33f404154ae783e21a3cd04debce285617175e91e5',1,'mfrc522.h']]],
  ['rxgain_5f18db_5f2_2',['RxGain_18dB_2',['../mfrc522_8h.html#a05e738f69d5036abf5520bd33f404154ad93f6335a036d9bc7ee7d295cd8279ea',1,'mfrc522.h']]],
  ['rxgain_5f23db_3',['RxGain_23dB',['../mfrc522_8h.html#a05e738f69d5036abf5520bd33f404154aaa2fffa436ddd1981bb3a54797075898',1,'mfrc522.h']]],
  ['rxgain_5f23db_5f2_4',['RxGain_23dB_2',['../mfrc522_8h.html#a05e738f69d5036abf5520bd33f404154a3cbff75dfcd5b393d4cad91bbc24f178',1,'mfrc522.h']]],
  ['rxgain_5f33db_5',['RxGain_33dB',['../mfrc522_8h.html#a05e738f69d5036abf5520bd33f404154a6c5a6315b74dbb560f9b24290c81b9cb',1,'mfrc522.h']]],
  ['rxgain_5f38db_6',['RxGain_38dB',['../mfrc522_8h.html#a05e738f69d5036abf5520bd33f404154adc585e1f70719fe376117b4bfcd76430',1,'mfrc522.h']]],
  ['rxgain_5f43db_7',['RxGain_43dB',['../mfrc522_8h.html#a05e738f69d5036abf5520bd33f404154a02f1185c3c59308ee5a74f6ac57bda77',1,'mfrc522.h']]],
  ['rxgain_5f48db_8',['RxGain_48dB',['../mfrc522_8h.html#a05e738f69d5036abf5520bd33f404154aba95ead7f5eb53e7bec7c4658fcc3ee6',1,'mfrc522.h']]],
  ['rxgain_5favg_9',['RxGain_avg',['../mfrc522_8h.html#a05e738f69d5036abf5520bd33f404154a33edea5792ee01a2559d09f3c43644c9',1,'mfrc522.h']]],
  ['rxgain_5fmax_10',['RxGain_max',['../mfrc522_8h.html#a05e738f69d5036abf5520bd33f404154a8160224539130816ab2a36c934e76f7a',1,'mfrc522.h']]],
  ['rxgain_5fmin_11',['RxGain_min',['../mfrc522_8h.html#a05e738f69d5036abf5520bd33f404154ab2b84169f41f2f26cb4bb7b28cef6509',1,'mfrc522.h']]],
  ['rxmodereg_12',['RxModeReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aad41dd120ed65d1a8c29f4c4c0417ce00',1,'mfrc522.h']]],
  ['rxselreg_13',['RxSelReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aade3ccc071a52b725776c64d2f157cc23',1,'mfrc522.h']]],
  ['rxthresholdreg_14',['RxThresholdReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aa4223799a2a908e98ec7c5c4853192f17',1,'mfrc522.h']]]
];
