var searchData=
[
  ['sak_0',['sak',['../struct_uid.html#adab6cfeddc24d859075a09bf20989e9b',1,'Uid']]],
  ['sck_5fpin_1',['sck_pin',['../mfrc522_8h.html#ae46d38e2942e51b5cacb17b98c75ad00',1,'mfrc522.h']]],
  ['security_5fpin_2',['security_pin',['../inventory_8h.html#a997a32afaf673d8f59742d18e3b97b0f',1,'inventory.h']]],
  ['self_5ftest_5fbytes_3',['SELF_TEST_BYTES',['../mfrc522_8h.html#a1c221febff7b55752a463c86d116c091',1,'mfrc522.h']]],
  ['size_4',['size',['../struct_uid.html#ae5dc6ffcd9b7605c7787791e40cc6bb0',1,'Uid']]],
  ['spi_5',['spi',['../struct_m_f_r_c522___t.html#ab49cde4743bdba856e515f6b0ff9e211',1,'MFRC522_T']]],
  ['spi_5fgap010_5fsample1_5fprogram_6',['spi_gap010_sample1_program',['../cyw43__bus__pio__spi_8pio_8h.html#ab262dd480c10ed772ceef2fd05cbb3d5',1,'cyw43_bus_pio_spi.pio.h']]],
  ['spi_5fgap010_5fsample1_5fprogram_5finstructions_7',['spi_gap010_sample1_program_instructions',['../cyw43__bus__pio__spi_8pio_8h.html#a800dfceb038818aa37e97f72f26fbc8a',1,'cyw43_bus_pio_spi.pio.h']]],
  ['spi_5fgap01_5fsample0_5fprogram_8',['spi_gap01_sample0_program',['../cyw43__bus__pio__spi_8pio_8h.html#a72293a981336352895e9e20b4fa7aeb1',1,'cyw43_bus_pio_spi.pio.h']]],
  ['spi_5fgap01_5fsample0_5fprogram_5finstructions_9',['spi_gap01_sample0_program_instructions',['../cyw43__bus__pio__spi_8pio_8h.html#a0f8c328b4f623e559fb5f569c677ff4f',1,'cyw43_bus_pio_spi.pio.h']]],
  ['spi_5fgap0_5fsample1_5fprogram_10',['spi_gap0_sample1_program',['../cyw43__bus__pio__spi_8pio_8h.html#a87011b135e77728ae517ccf4fec4cd2f',1,'cyw43_bus_pio_spi.pio.h']]],
  ['spi_5fgap0_5fsample1_5fprogram_5finstructions_11',['spi_gap0_sample1_program_instructions',['../cyw43__bus__pio__spi_8pio_8h.html#a3ceb8656216bf71338f81d58d90a9f89',1,'cyw43_bus_pio_spi.pio.h']]],
  ['spi_5fgap0_5fsample1_5fregular_5fprogram_12',['spi_gap0_sample1_regular_program',['../cyw43__bus__pio__spi_8pio_8h.html#a9b712c4cfd2dfb1cc54a1fb3a5741159',1,'cyw43_bus_pio_spi.pio.h']]],
  ['spi_5fgap0_5fsample1_5fregular_5fprogram_5finstructions_13',['spi_gap0_sample1_regular_program_instructions',['../cyw43__bus__pio__spi_8pio_8h.html#a46a2f713c350c51f946b4cb2ef13bf05',1,'cyw43_bus_pio_spi.pio.h']]],
  ['str_14',['str',['../inventory_8h.html#ab050508039ecfee8aa8ede145adf0487',1,'inventory.h']]]
];
