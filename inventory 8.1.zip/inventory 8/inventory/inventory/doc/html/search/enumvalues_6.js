var searchData=
[
  ['gsnreg_0',['GsNReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aa18525a1f448dfe6f1cc5518f445808b5',1,'mfrc522.h']]]
];
