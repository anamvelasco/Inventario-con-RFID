var searchData=
[
  ['mfrc522ptr_5ft_0',['MFRC522Ptr_t',['../mfrc522_8h.html#a08c3a10bca51453a3ef3bf91aca43aaa',1,'mfrc522.h']]],
  ['mifare_5fmisc_1',['MIFARE_Misc',['../mfrc522_8h.html#aa8bb6cbf3b90d8bf010ff10ff4bd9a79',1,'mfrc522.h']]]
];
