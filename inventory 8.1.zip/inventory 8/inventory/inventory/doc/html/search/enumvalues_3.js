var searchData=
[
  ['demodreg_0',['DemodReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aa014872a109d79ca940f229e2af57c8ee',1,'mfrc522.h']]],
  ['divienreg_1',['DivIEnReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aa2fc92cf6493376dc4d00802fa8b2d5ac',1,'mfrc522.h']]],
  ['divirqreg_2',['DivIrqReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aaedce030257bab38b99b092b0cd689fa6',1,'mfrc522.h']]]
];
