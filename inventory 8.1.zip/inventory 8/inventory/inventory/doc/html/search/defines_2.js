var searchData=
[
  ['buffer_5fsize_0',['BUFFER_SIZE',['../mfrc522_8h.html#a6b20d41d6252e9871430c242cb1a56e7',1,'mfrc522.h']]],
  ['button_5fpin_1',['BUTTON_PIN',['../inventory_8h.html#abc2ad14f0789907024ac765711ffd3da',1,'inventory.h']]]
];
