var searchData=
[
  ['mfrc522_5ft_0',['MFRC522_T',['../struct_m_f_r_c522___t.html',1,'']]],
  ['mifare_5fkey_1',['MIFARE_Key',['../struct_m_i_f_a_r_e___key.html',1,'']]]
];
