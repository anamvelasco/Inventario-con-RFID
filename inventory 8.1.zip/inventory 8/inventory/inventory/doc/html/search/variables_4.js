var searchData=
[
  ['fifo_5fsize_0',['FIFO_SIZE',['../mfrc522_8h.html#a59c0dd29d930b0c298965ce51de7915c',1,'mfrc522.h']]]
];
