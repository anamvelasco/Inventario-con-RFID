var searchData=
[
  ['rows_0',['rows',['../inventory_8h.html#a01ac8f9a863c8b12f9b86a33f6829b8c',1,'inventory.h']]],
  ['rx_5fbuf_1',['Rx_Buf',['../struct_m_f_r_c522___t.html#a2f72c8cdcabe724d41552c5f7e56e8a5',1,'MFRC522_T']]]
];
