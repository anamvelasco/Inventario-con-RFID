var searchData=
[
  ['admin_5fcard_5fauthentication_0',['admin_card_authentication',['../inventory_8h.html#a5199277e8f0a447ab1122309af46930d',1,'inventory.h']]]
];
