var searchData=
[
  ['manager_0',['Inventory Manager',['../index.html',1,'']]]
];
