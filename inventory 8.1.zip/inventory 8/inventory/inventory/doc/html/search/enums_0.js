var searchData=
[
  ['_5fmifare_5fmisc_0',['_MIFARE_Misc',['../mfrc522_8h.html#a53ebd42d413bbb43ea0113768e19b4ed',1,'mfrc522.h']]],
  ['_5fpcd_5fcommand_1',['_PCD_Command',['../mfrc522_8h.html#aeb56e82004c22536304a1f80a97ea3a1',1,'mfrc522.h']]],
  ['_5fpcd_5frxgain_2',['_PCD_RxGain',['../mfrc522_8h.html#a05e738f69d5036abf5520bd33f404154',1,'mfrc522.h']]],
  ['_5fpicc_5fcommand_3',['_PICC_Command',['../mfrc522_8h.html#a7d99cfbcd2fcf0c9a7898cddfd8c5b38',1,'mfrc522.h']]],
  ['_5fpicc_5ftype_4',['_PICC_Type',['../mfrc522_8h.html#ae015bc636f5f32a5757c5edc94fd7c53',1,'mfrc522.h']]],
  ['_5fstatuscode_5',['_StatusCode',['../mfrc522_8h.html#a24e4449d0fd4deb887fec01350519352',1,'mfrc522.h']]]
];
