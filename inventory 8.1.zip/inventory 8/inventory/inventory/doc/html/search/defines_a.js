var searchData=
[
  ['reset_5fpin_0',['RESET_PIN',['../mfrc522_8h.html#a08bca59db4b190eaaea4d47b7562869c',1,'mfrc522.h']]],
  ['rst_5fpin_1',['RST_PIN',['../inventory_8h.html#a36932b0e869e0114f32e255f61306d6b',1,'inventory.h']]]
];
