var searchData=
[
  ['statuscode_0',['StatusCode',['../mfrc522_8h.html#a5f21394f47e041c904141d6d8c684a12',1,'mfrc522.h']]]
];
