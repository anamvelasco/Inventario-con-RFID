var searchData=
[
  ['serialspeedreg_0',['SerialSpeedReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aa28ceb9360e96b4b20a8883599315c01b',1,'mfrc522.h']]],
  ['status1reg_1',['Status1Reg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aa6ea29a9b63ec9c13e8d627c6581e7434',1,'mfrc522.h']]],
  ['status2reg_2',['Status2Reg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aaeda87f0a127438e52c8cbbc9249da8b2',1,'mfrc522.h']]],
  ['status_5fcollision_3',['STATUS_COLLISION',['../mfrc522_8h.html#a24e4449d0fd4deb887fec01350519352a7fd83b17a51cb26331b3dcd55f2466eb',1,'mfrc522.h']]],
  ['status_5fcrc_5fwrong_4',['STATUS_CRC_WRONG',['../mfrc522_8h.html#a24e4449d0fd4deb887fec01350519352aa8c257d56a1a9e9545daf6eccbb634a4',1,'mfrc522.h']]],
  ['status_5ferror_5',['STATUS_ERROR',['../mfrc522_8h.html#a24e4449d0fd4deb887fec01350519352a5bde228d9506a863d51ffbc868ff67f7',1,'mfrc522.h']]],
  ['status_5finternal_5ferror_6',['STATUS_INTERNAL_ERROR',['../mfrc522_8h.html#a24e4449d0fd4deb887fec01350519352adbee399e52770145a726e8bf2a7d6c83',1,'mfrc522.h']]],
  ['status_5finvalid_7',['STATUS_INVALID',['../mfrc522_8h.html#a24e4449d0fd4deb887fec01350519352ae83d84fa3518dd04613345b248bc1994',1,'mfrc522.h']]],
  ['status_5fmifare_5fnack_8',['STATUS_MIFARE_NACK',['../mfrc522_8h.html#a24e4449d0fd4deb887fec01350519352a32429e8c1a1d8406c25fa6f624f4b71b',1,'mfrc522.h']]],
  ['status_5fno_5froom_9',['STATUS_NO_ROOM',['../mfrc522_8h.html#a24e4449d0fd4deb887fec01350519352a674f7ef13433296186dedf23f803a552',1,'mfrc522.h']]],
  ['status_5fok_10',['STATUS_OK',['../mfrc522_8h.html#a24e4449d0fd4deb887fec01350519352a7e4a42e3b6dd63708c64cf3db6f69566',1,'mfrc522.h']]],
  ['status_5ftimeout_11',['STATUS_TIMEOUT',['../mfrc522_8h.html#a24e4449d0fd4deb887fec01350519352a1d57e6000a93a7eb812752846715a58c',1,'mfrc522.h']]]
];
