var searchData=
[
  ['bitframingreg_0',['BitFramingReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aa151ffe13df9f13c2af35ba5266501892',1,'mfrc522.h']]]
];
