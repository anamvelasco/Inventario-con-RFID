var searchData=
[
  ['fifodatareg_0',['FIFODataReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aa01dc77e2d3c47d73e537279c4927b245',1,'mfrc522.h']]],
  ['fifolevelreg_1',['FIFOLevelReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aa0995903df8bc2dd4c6cdd358f898a165',1,'mfrc522.h']]]
];
