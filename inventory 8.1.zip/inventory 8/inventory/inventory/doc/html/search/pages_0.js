var searchData=
[
  ['inventory_20manager_0',['Inventory Manager',['../index.html',1,'']]]
];
