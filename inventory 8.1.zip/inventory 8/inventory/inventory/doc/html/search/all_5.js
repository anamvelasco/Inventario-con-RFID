var searchData=
[
  ['errorreg_0',['ErrorReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aaf2d8d4c5f2c3734b1ccb6bae8c9d9ba8',1,'mfrc522.h']]]
];
