var searchData=
[
  ['matrix_0',['matrix',['../inventory_8h.html#ac2bcd200220410cf5d36cca87ad2b481',1,'inventory.h']]],
  ['max_5fprod_5f1_1',['max_prod_1',['../inventory_8h.html#ab59e4f3c1dfeb614e6f1f11eb011334a',1,'inventory.h']]],
  ['max_5fprod_5f2_2',['max_prod_2',['../inventory_8h.html#a7e70f1cb5ad29a3a1242810d7d4948d6',1,'inventory.h']]],
  ['max_5fprod_5f3_3',['max_prod_3',['../inventory_8h.html#aaed06ecacf2394f3f391dda1f0bfb611',1,'inventory.h']]],
  ['max_5fprod_5f4_4',['max_prod_4',['../inventory_8h.html#a8308ccdfc2c95207d7fe4b245b40c173',1,'inventory.h']]],
  ['max_5fprod_5f5_5',['max_prod_5',['../inventory_8h.html#a880aa09b9c09080c8eb425fa9d233149',1,'inventory.h']]],
  ['message_6',['message',['../inventory_8h.html#a2c27107532340d4810ec3df67be5bf30',1,'inventory.h']]],
  ['mfrc522_7',['mfrc522',['../inventory_8h.html#a1cde7bdcfda1457cd6b52cb58ce49717',1,'inventory.h']]],
  ['mfrc_5finstance_5fcounter_8',['MFRC_Instance_Counter',['../mfrc522_8c.html#af68ae456a549ff95b71be22a17455c0b',1,'mfrc522.c']]],
  ['miso_5fpin_9',['miso_pin',['../mfrc522_8h.html#a0bee9d6d5085dfadd66b97f95b55b155',1,'mfrc522.h']]],
  ['mosi_5fpin_10',['mosi_pin',['../mfrc522_8h.html#a1cdab6ea845cd7f7a8a488977b6e08b9',1,'mfrc522.h']]]
];
