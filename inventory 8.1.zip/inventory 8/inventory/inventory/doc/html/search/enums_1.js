var searchData=
[
  ['pcd_5fregister_0',['PCD_Register',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203a',1,'mfrc522.h']]]
];
