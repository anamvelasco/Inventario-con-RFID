var searchData=
[
  ['collreg_0',['CollReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aa810a84a55c584d99949dbe26f19cdb62',1,'mfrc522.h']]],
  ['comienreg_1',['ComIEnReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aa506e05cdfebf3d6cc364346913e407ab',1,'mfrc522.h']]],
  ['comirqreg_2',['ComIrqReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aaee02ac5376aaf7c0ec7d6d42f01d947d',1,'mfrc522.h']]],
  ['commandreg_3',['CommandReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aadda3b12e0c86e916d4b6b29a5d555016',1,'mfrc522.h']]],
  ['controlreg_4',['ControlReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aa794a3f84717e8b4e7c8af89cbe9f7441',1,'mfrc522.h']]],
  ['crcresultregh_5',['CRCResultRegH',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aa48129bbe2af54ddf2c64f01eb8c788ee',1,'mfrc522.h']]],
  ['crcresultregl_6',['CRCResultRegL',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aa9b58509764a5ed0d77da0a506e463f5f',1,'mfrc522.h']]],
  ['cwgspreg_7',['CWGsPReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aa209b2fc5a1902c250a20b629bb141a62',1,'mfrc522.h']]]
];
