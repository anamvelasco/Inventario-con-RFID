var searchData=
[
  ['analogtestreg_0',['AnalogTestReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aaff82eacb697dc71213dab392cd08fa1c',1,'mfrc522.h']]],
  ['autotestreg_1',['AutoTestReg',['../mfrc522_8h.html#a7380aa98144f0d378c6ec0c5af89203aa8c551d97f4fe9e636a7419babb652e5b',1,'mfrc522.h']]]
];
